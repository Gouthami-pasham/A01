# Web Tic Tac Toe

Simple game using CSS Grid

Source: <https://github.com/profcase/web-tic-tac-toe>

Demo: <https://profcase.github.io/web-tic-tac-toe/>